
#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

int main()
{
	//double ipk = 3.66;
	//string jurusan = "ISB";
	//string nama = "CHen";
	//int nim = 0706022310016;
	//cout << "nama : " << nama << endl;
	//cout << "Jurusan : " << jurusan << endl;
	//cout << "nim : " << nim << endl;
	//cout << "ipk : " << ipk;
	//return 0;

	//string nama;
	//string jurusan;
	//string nim;
	//string ipk_str;
	//double ipk;
	//

	//cout << "masukkan nama : " ;
	//getline(cin, nama);

	//cout << "masukkan juruasan : ";
	//getline(cin, jurusan);

	//cout << "masukkan nim : ";
	//getline(cin, nim);

	//cout << "masukkan ipk : ";
	//getline(cin, ipk_str);
	//ipk = stod(ipk_str);

	// -------------------------------------------------------------------------------------------------------------------------

	//// if....else statement

	//string result = (ipk > 3.5) ? "Cumlaude" : "tidak cumlaude";


	//cout << "nama : " << nama << endl;
	//cout << "jurusan : " << jurusan << endl;
	//cout << "nim : " << nim << endl;
	//cout << "ipk : " << ipk << endl;
	//cout << "Predikat :  " << result << endl;
	//return 0;


	//string namabaru;
	//cin >> namabaru;
	//cout << namabaru;
	//string nama_panjang;
	//getline(cin, nama_panjang);

	//cout << nama_panjang;

	//double ipk = 2.9;
	//if (ipk >= 3.75) {
	//	cout << "summa cumlaude";
	//}
	//else if (ipk >= 3.50 && ipk <= 3.75) {
	//	cout << "Cumlaude";
	//}
	//else {
	//	cout << "yang penting lulus";
	//}
	//return 0;
	// -------------------------------------------------------------------------------------------------------------------------
	// for loop & while loop

	//for (inisialisasi; kondisi; perubahan) {
		// kode berulang
	//}

	//while (kondisi) {
		// kode berulang
	//}


	//for (int i = 1; i <= 5; i++)
	//{
	//	cout << i << endl;
	//}

	//int angka = 0;
	//cout << "sekarang while :";
	//while (angka <= 10) {
	//	cout << angka << endl;
	//	angka++;
	//}

	//cout << "sekarang do :";
	//do {
	//	cout << angka << endl;
	//	angka++;
	//} while (angka <= 10);	
	//return 0;
	// -------------------------------------------------------------------------------------------------------------------------
	//latian
	char choice = 'y';
	while (choice == 'y') {
		string nama_lenkap, jurusan, NIM, ipk, result;
		cout << "input Nama Lengkap : ";
		getline(cin, nama_lenkap);

		cout << "Input Jurusan : ";
		getline(cin, jurusan);

		cout << "Input NIM : ";
		getline(cin, NIM);

		cout << "Input ipk : ";
		getline(cin, ipk);
		system("cls");

		double ipk_double = stod(ipk);
		if (ipk_double > 4.00 || ipk_double < 0) {
			cout << "IPK tidak Valid" << endl;
			cout << "restart ? [y] / [n]" << endl;

			if (choice == 'y') {
				choice = 'y';
			}
			else if (choice == 'n') {
				choice = 'n';
			}
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			system("cls");
		}
		else {
			if (ipk_double >= 3.75 && ipk_double <=4.00) {
				result = "Summa Cumlaude";
			}
			else if (ipk_double >= 3.50 && ipk_double < 3.75) {
				result = "Cumlaude";
			}
			else if (ipk_double >= 3.00 && ipk_double < 3.50) {
				result = "Sangat Memuaskan";
			}
			else if (ipk_double < 3.00) {
				result = "Memuaskan";
			}

			cout << "Nama Lengkap : " << nama_lenkap << endl;
			cout << "Jurusan : " << jurusan << endl;
			cout << "NIM : " << NIM << endl;
			cout << "IPK : " << ipk_double << endl;
			cout << "Predikat : " << result << endl;
			cout << "restart ? [y] / [n]" << endl;
			cin >> choice;

			if (choice == 'y') {
				choice = 'y';
			}
			else if (choice == 'n') {
				choice = 'n';
			}
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			system("cls");
		}
	}
	return 0;

	


}


