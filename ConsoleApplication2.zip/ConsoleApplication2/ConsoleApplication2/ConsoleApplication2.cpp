// ConsoleApplication2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

void sikusiku(int input);
void samakaki(int input);

int main()
{
    int input;

    cout << "Masukkan angka random : ";
    cin >> input;

    cout << "\nSegitiga Siku-Siku:\n";
    sikusiku(input);

    cout << "\nSegitiga Sama Kaki:\n";
    samakaki(input);

    return 0;
}

void sikusiku(int input)
{
    for (int i = 1; i <= input; i++)
    {
        //cout << "*";
        for (int j = 1; j <= i; j++)
        {
            cout << "*";
        }
        cout << "\n";
    }

}

void samakaki(int input )
{
    for (int i = 1; i <= input; i++)
    {
        for (int j = 1; j <= input - i; j++)
        {
            cout << " ";
        }

        for (int k = 1; k <= (2 * i - 1); k++)
        {
            cout << "*";
        }
        cout << "\n";
    }

}


