// ConsoleApplication4.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>
using namespace std;

double simbol(double total)
{
	if (total >= 85)
	{
		cout << "Grade: A";
	}
	else if (total < 85 && total >= 70)
	{
		cout << "Grade: B";
	}
	else if (total < 70 && total >= 55)
	{
		cout << "Gradw: C";
	}
	else if (total < 55)
	{
		cout << "Gradw: D";
	}
	return 0;
}

double rata_rata(vector<int> nilai_siswa, int siswa)
{
	double total = 0;
	for (int i = 0; i < nilai_siswa.size(); i++)
	{
		total += nilai_siswa[i];
	}
	cout << "Rata - Rata: " << (total / siswa) << endl;
	simbol(total);
	return 0;

}

int kecil_besar(vector<int>nilai_siswa)
{
	cout << "Angka terbesar : " << *max_element(nilai_siswa.begin(), nilai_siswa.end()) << endl;
	cout << "Angka terkecil : " << *min_element(nilai_siswa.begin(), nilai_siswa.end()) << endl;
	return 0;
}

int main()
{
	int siswa;
	cout << "Siswa : ";
	cin >> siswa;
	int score;
	vector<int> nilai_siswa;
	for (int i = 0; i < siswa; i++)
	{
		bool lebih = true;
		while (lebih == true)
		{
			cout << "masukkan nilai siswa : ";
			cin >> score;
			if (score > 100)
			{
				lebih = true;
				cout << "Nilai tidak bisa lebih dari 100" << endl;
			}
			else if (score < 0)
			{
				lebih = true;
				cout << "Nilai tidak bisa kurang dari 0" << endl;
			}
			else {
				lebih = false;
				nilai_siswa.push_back(score);
			}	
		}
	}
	kecil_besar(nilai_siswa);
	rata_rata(nilai_siswa, siswa);
	return 0;
////-----------------------------------------------------------------------------------------------------------
// 	  
//Latihan 1
//Buat array berisi 5 angka
//Hitung rata - rata

//	int angka[5];
//	int total = 0;
//	for (int i = 0; i <= 4; i++)
//	{
//		cout << "angka ke " << i + 1 << ":";
//		cin >> angka[i];
//	}
//	for (int j = 0; j <= 4;j++)
//	{
//		total += angka[j];
//	}
//
//	cout << total << endl;
//	cout << "rata-rata angka : " << total / 5;
//
////-----------------------------------------------------------------------------------------------------------
//Latihan 2
//Input n data(pakai vector)
//Tampilkan:
//nilai terbesar
//nilai terkecil

//	int n;
//	cout << "berapa  angka yang akan dimasukkan : ";
//	cin >> n;
//	int x;
//	vector<int> angka;
//
//	for (int i = 0; i <= n; i++)
//	{
//		cout << "masukkan angka : ";
//		cin >> x;
//		angka.push_back(x);
//	}
//
//	cout << "angka terbesar : " << *max_element(angka.begin(), angka.end()) << endl;
//	cout << "angka terkecil : " << *min_element(angka.begin(), angka.end());
//	return 0;
////-----------------------------------------------------------------------------------------------------------
}